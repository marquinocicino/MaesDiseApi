const config = {
    PORT: 3000, 
    DB_URL: 'mongodb+srv://marco1989delrio:O2jy9UeoM6Mdo5Qk@cluster0.kajjcpa.mongodb.net/?retryWrites=true&w=majority'            
}

module.exports = config