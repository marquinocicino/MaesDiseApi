const Model = require('./model')

async function agregarPais( dato ) {
    const resultado = await new Model( dato )
    return resultado.save()
}

async function obtenerPais( filtro ) {
    console.log("filtro................");
    console.log(filtro);
    
    let mi_filtro = {}

    if (filtro) {
        mi_filtro = {codigo: filtro}
    }
    const resultado =  await Model.find(mi_filtro)
    return resultado
}

/*
async function actualizarPais(dato) {
    const nuevo_objeto = await Model.findOne( {codigo: dato} )

    nuevo_objeto.nombre = dato.nombre 
    
    const resultado = await nuevo_objeto.save()
    return resultado
}*/

 

async function actualizarPais( pais ) {
    const objeto = await Model.findOne( {codigo: pais.codigo} )

    if ( objeto ) {
        objeto.nombre = pais.nombre
    
        return resultado = await objeto.save()    
    } else {
        return null
    }
}





async function eliminarPais(dato) {
    console.log("eliminar")
    ///console.log(dato) eliminar objetos
    const resultado = await Model.deleteOne( {codigo: dato.codigo} )
    return resultado
}

module.exports = {
    agregar:agregarPais,
    obtener:obtenerPais,
    actualizar:actualizarPais,
    eliminar:eliminarPais
}