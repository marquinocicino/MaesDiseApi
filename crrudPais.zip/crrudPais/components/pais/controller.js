const storage = require('./storage')

function agregarPais( dato ) {
    return new Promise((resolve, reject) => {
        resolve( storage.agregar( dato ) )
    })
}

function obtenerPais( filtro ) {
    console.log("Obtener pais!");
    return new Promise((resolve, reject) => {
        resolve( storage.obtener( filtro ) )
    })
}
 


function actualizarPais( pais ) {
    return new Promise((resolve, reject) => {
        let resultado = storage.actualizar( pais )
        console.log(pais)
        if (resultado) {
            return resolve( pais )
        } else {
            return reject('No existe el pais.')
        }
    })
}




function eliminarPais( dato ) {
    return new Promise((resolve, reject) => {
      
        resolve( storage.eliminar( dato ) )
    })    
}

module.exports = {
    agregarPais,
    obtenerPais,
    actualizarPais,
    eliminarPais
}